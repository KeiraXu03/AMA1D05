# humanpose > 2024-01-27 9:30pm
https://universe.roboflow.com/tiger-pgide/humanpose-v2f7g

Provided by a Roboflow user
License: CC BY 4.0

